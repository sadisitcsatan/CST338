public class RangedAttack implements Attack {
    Monster attacker;
    public MeleeAttack(Monster m){
        this.attacker = m;
    }
    @Override
    public Integer Attack(Monster target){
        String message = attacker + " uses a melee attack on " + target;
        System.out.println(message);
        return null;
    }

}
