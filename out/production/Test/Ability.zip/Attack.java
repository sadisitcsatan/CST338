public interface Attack extends Ability {
     Integer attack(Monster m);
}
